public interface IUsuario {

    public Boolean autentc();
}
