public class Debito {

    private Double valor;

    public Debito(Double valor){
        this.setValor(valor);
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }
}
